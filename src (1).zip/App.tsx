import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { AuthProvider, useAuth } from '@/context/auth'
import Nav from '@/components/Nav'
import Footer from '@/components/Footer'
import FAQ from '@/components/FAQ'
import Home from '@/pages/Home'
import About from '@/pages/About'
import Services from '@/pages/Services'
import Bookkeeping from '@/pages/Bookkeeping'
import Taxation from '@/pages/Taxation'
import Advisory from '@/pages/Advisory'
import ITInsurance from '@/pages/ITInsurance'
import Contact from '@/pages/Contact'
import Login from '@/pages/Login'
import ClientDashboard from '@/pages/ClientDashboard'
import AdminDashboard from '@/pages/AdminDashboard'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo(0, 0) }, [pathname])
  return null
}

function WithLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Nav />
      <main className="flex-1 pt-[4.5rem]">{children}</main>
      <Footer />
    </div>
  )
}

function ProtectedRoute({ children, role }: { children: React.ReactNode; role: 'client' | 'admin' }) {
  const { user } = useAuth()
  if (!user) return <Navigate to="/login" replace />
  if (user.role !== role) return <Navigate to={user.role === 'admin' ? '/admin' : '/dashboard'} replace />
  return <>{children}</>
}

function AppRoutes() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<WithLayout><Home /></WithLayout>} />
        <Route path="/about" element={<WithLayout><About /></WithLayout>} />
        <Route path="/services" element={<WithLayout><Services /></WithLayout>} />
        <Route path="/services/bookkeeping" element={<WithLayout><Bookkeeping /></WithLayout>} />
        <Route path="/services/taxation" element={<WithLayout><Taxation /></WithLayout>} />
        <Route path="/services/advisory" element={<WithLayout><Advisory /></WithLayout>} />
        <Route path="/services/it-insurance" element={<WithLayout><ITInsurance /></WithLayout>} />
        <Route path="/contact" element={<WithLayout><Contact /></WithLayout>} />
        <Route path="/faq" element={<WithLayout><FAQ /></WithLayout>} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute role="client">
              <ClientDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <ProtectedRoute role="admin">
              <AdminDashboard />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  )
}
