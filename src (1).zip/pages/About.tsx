import { Link } from 'react-router-dom'

const values = [
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M11 2C6.03 2 2 6.03 2 11s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9z" stroke="#2461be" strokeWidth="1.5"/>
        <path d="M11 6v5l3 3" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Client First',
    desc: 'Every decision, recommendation, and engagement starts and ends with the client\'s best interests in mind.',
  },
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M11 2l2.09 6.26H19l-5.45 3.95 2.09 6.26L11 14.5l-4.64 3.97 2.09-6.26L3 8.26h5.91L11 2z" stroke="#2461be" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Integrity',
    desc: 'We hold ourselves to the highest professional standards—honest counsel, transparent fees, and no conflicts of interest.',
  },
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M9 3H5a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2h-4" stroke="#2461be" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M9 3a2 2 0 012-2h0a2 2 0 012 2v0a2 2 0 01-2 2h0a2 2 0 01-2-2z" stroke="#2461be" strokeWidth="1.5"/>
        <path d="M7 12h8M7 16h5" stroke="#2461be" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    ),
    title: 'Precision',
    desc: 'Accounting demands accuracy. We apply meticulous attention to detail in every file, return, and report we produce.',
  },
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M4 14l4-4 4 4 6-6" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M14 8h4v4" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Growth',
    desc: 'We measure our success by the success of our clients—every engagement is an opportunity to help them grow.',
  },
]

export default function About() {
  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-24 bg-navy relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1542081403278-ba5973c25c7a?w=1600&h=700&fit=crop&auto=format"
            alt="Professional office environment"
            className="w-full h-full object-cover opacity-10"
          />
          <div className="absolute inset-0 bg-navy/90" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-3xl">
            <div className="mb-4 text-xl sm:text-2xl font-semibold tracking-wide text-white">About ThinkBizz</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-6 leading-tight">
              We Think Business.<br />We Think You.
            </h1>
            <p className="text-white/70 text-xl leading-relaxed">
              ThinkBizz Business Solutions is a Canadian accounting outsourcing, tax and advisory firm built on the principle that every client deserves a solution built around them.
            </p>
          </div>
        </div>
      </section>

      {/* Our Approach */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="section-label mb-3">Our Approach</div>
              <h2 className="font-display text-4xl font-semibold text-navy mb-5">
                Built on listening. Powered by expertise.
              </h2>
              <div className="divider-accent" />
              <div className="mt-6 flex flex-col gap-4 text-[#3d5070] leading-relaxed">
                <p>
                  ThinkBizz was founded with a straightforward conviction: too many businesses receive one-size-fits-all financial advice that does not reflect the complexity of their real situation.
                </p>
                <p>
                  We take the time to understand your business model, your industry pressures, and your personal goals before we offer a single recommendation. The result is advice that is genuinely useful—not advice that sounds good in a brochure.
                </p>
                <p>
                  Whether you are a sole proprietor filing your first return, a growing corporation that needs a Virtual CFO, or an established business preparing for a transaction, we bring the same rigour and dedication to every file.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1748764720733-3bb4c52ab6f9?w=800&h=600&fit=crop&auto=format"
                alt="Modern professional environment"
                className="w-full h-80 object-cover rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-[#f7f9fc]">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-14">
            <div className="section-label mb-3">Our Values</div>
            <h2 className="font-display text-4xl font-semibold text-navy mb-4">What guides everything we do</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map(v => (
              <div key={v.title} className="bg-white border border-[#d8e0ec] rounded-xl p-7">
                <div className="w-12 h-12 bg-[#eef2fb] rounded-xl flex items-center justify-center mb-5">
                  {v.icon}
                </div>
                <h3 className="font-display text-xl font-semibold text-navy mb-3">{v.title}</h3>
                <p className="text-[#6b7c99] text-[0.9375rem] leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="py-24 bg-white">
        <div className="max-w-5xl mx-auto px-5 lg:px-8">
          <div className="section-label mb-3 text-center">Leadership</div>
          <h2 className="font-display text-4xl font-semibold text-navy mb-14 text-center">Your Team</h2>

          <div className="bg-surface border border-border rounded-2xl p-8 lg:p-12">
            <div>
              <div className="flex flex-col gap-4 text-[#3d5070] leading-relaxed">
                <p>
                  Nilesh Patel is a senior professional accountant with extensive experience across accounting, bookkeeping, taxation, and financial advisory services—both locally in Canada and in international markets.
                </p>
                <p>
                  His professional background encompasses audit, financial reporting, and advisory engagements for clients ranging from individuals and sole proprietors to established corporations. He brings a high standard of technical competence and a genuine client-first approach to every file.
                </p>
              </div>

              <div className="mt-8 bg-white border border-[#d8e0ec] rounded-xl p-5">
                <div className="text-[#6b7c99] text-xs font-semibold tracking-widest uppercase mb-2">Contact</div>
                <a href="mailto:info@thinkbizzsolutions.com" className="text-[#2461be] text-sm font-medium hover:underline">
                  info@thinkbizzsolutions.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-navy">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <h2 className="font-display text-4xl font-semibold text-white mb-5">Work with a firm that puts you first.</h2>
          <p className="text-white/70 text-lg mb-8">Reach out today to discuss how ThinkBizz can support your business.</p>
          <Link to="/contact" className="btn-white">Get in Touch</Link>
        </div>
      </section>
    </div>
  )
}
