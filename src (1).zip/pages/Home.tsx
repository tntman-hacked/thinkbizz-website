import { Link } from 'react-router-dom'

const services = [
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M9 12h6M9 16h4" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round"/>
      </svg>
    ),
    title: 'Bookkeeping & Virtual CFO',
    desc: 'Keep your books clean and your business decisions sharp.',
    to: '/services/bookkeeping',
    tag: 'Financial Management',
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M9 14l2 2 4-4" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M3 7a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7z" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round"/>
      </svg>
    ),
    title: 'Taxation',
    desc: 'Personal and corporate tax compliance and strategic consulting.',
    to: '/services/taxation',
    tag: 'Tax Services',
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Advisory',
    desc: 'Trusted guidance for growth, planning, and financial decisions.',
    to: '/services/advisory',
    tag: 'Business Advisory',
  },
  {
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="3" width="20" height="14" rx="2" stroke="#2461be" strokeWidth="1.75"/>
        <path d="M8 21h8M12 17v4" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round"/>
        <path d="M9 8.5l2 2 4-4" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Accounting Software',
    desc: 'Setup, training, and support for leading cloud accounting platforms.',
    to: '/services/it-insurance',
    tag: 'Technology',
  },
]

const reasons = [
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M11 2C6.03 2 2 6.03 2 11s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9z" stroke="#2d7d4f" strokeWidth="1.5"/>
        <path d="M7 11l3 3 5-5" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Tailored Solutions',
    desc: "No generic templates. Every engagement is built around the client's specific goals and situation.",
  },
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M11 2C6.03 2 2 6.03 2 11s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9z" stroke="#2d7d4f" strokeWidth="1.5"/>
        <path d="M11 7v4l3 3" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Experienced Team',
    desc: 'We listen closely and provide practical, insightful advice rooted in deep professional experience.',
  },
  {
    icon: (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
        <path d="M3 10l8-7 8 7v9a1 1 0 01-1 1H4a1 1 0 01-1-1v-9z" stroke="#2d7d4f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M9 20V14h4v6" stroke="#2d7d4f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
    title: 'Trusted Partner',
    desc: 'We aim to be a long-term business partner, not just someone you contact during tax season.',
  },
]

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-screen flex items-center bg-navy overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1614595737476-42487331b8a1?w=1600&h=900&fit=crop&auto=format"
            alt="Modern professional building"
            className="w-full h-full object-cover opacity-15"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/95 to-navy/70" />
        </div>
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-5">
          <svg viewBox="0 0 400 600" className="w-full h-full">
            <rect x="50" y="50" width="300" height="500" rx="2" stroke="white" strokeWidth="1" fill="none"/>
            <rect x="100" y="100" width="200" height="400" rx="2" stroke="white" strokeWidth="1" fill="none"/>
            <line x1="50" y1="300" x2="350" y2="300" stroke="white" strokeWidth="1"/>
          </svg>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8 py-32 pt-36">
          <div className="max-w-3xl">
            <div className="mb-6 text-lg sm:text-xl font-semibold tracking-wide text-white">Canadian Accounting Outsourcing, Tax & Advisory</div>
            <h1 className="font-display text-5xl lg:text-6xl xl:text-7xl font-semibold text-white leading-tight mb-7">
              Smart Financial Solutions for Ambitious Businesses
            </h1>
            <p className="text-white/70 text-xl leading-relaxed mb-10 max-w-xl">
              Accounting, Tax, and Advisory services tailored to your unique goals. We listen first, then build solutions around you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/contact" className="btn-white">Book a Consultation</Link>
              <Link to="/services" className="btn-white-outline">Explore Our Services</Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 60" fill="none" preserveAspectRatio="none" className="w-full h-12">
            <path d="M0 60L1440 60L1440 20C1200 60 960 0 720 20C480 40 240 0 0 20L0 60Z" fill="white"/>
          </svg>
        </div>
      </section>

      {/* Services */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-14">
            <div className="section-label mb-3">What We Do</div>
            <h2 className="font-display text-4xl lg:text-5xl font-semibold text-navy mb-4">Our Services</h2>
            <p className="text-[#6b7c99] text-lg max-w-xl mx-auto">
              Comprehensive professional services designed to support every dimension of your business.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map(s => (
              <Link key={s.title} to={s.to} className="card p-7 group block">
                <div className="service-icon bg-[#eef2fb] mb-5">{s.icon}</div>
                <div className="text-[0.75rem] font-semibold tracking-widest uppercase text-[#9aabb8] mb-2">{s.tag}</div>
                <h3 className="font-display text-xl font-semibold text-navy mb-3 leading-snug">{s.title}</h3>
                <p className="text-[#6b7c99] text-[0.9375rem] leading-relaxed mb-5">{s.desc}</p>
                <span className="text-[#2461be] text-sm font-semibold flex items-center gap-1.5 group-hover:gap-2.5 transition-all">
                  Learn more
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M2 7h10M8 3l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why ThinkBizz */}
      <section className="py-24 bg-[#f7f9fc]">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="section-label mb-3">Why ThinkBizz</div>
              <h2 className="font-display text-4xl lg:text-5xl font-semibold text-navy mb-5">
                A firm built around your business, not the other way around.
              </h2>
              <p className="text-[#3d5070] text-lg leading-relaxed mb-8">
                We believe every business deserves financial guidance that is precise, practical, and personal. Our approach starts with understanding your goals before we recommend a single solution.
              </p>
              <Link to="/about" className="btn-secondary">Learn About Us</Link>
            </div>
            <div className="flex flex-col gap-6">
              {reasons.map(r => (
                <div key={r.title} className="bg-white border border-[#d8e0ec] rounded-lg p-6 flex gap-5">
                  <div className="shrink-0 w-11 h-11 rounded-lg bg-[#e6f4ec] flex items-center justify-center">
                    {r.icon}
                  </div>
                  <div>
                    <h3 className="font-semibold text-navy text-[1.0625rem] mb-1.5">{r.title}</h3>
                    <p className="text-[#6b7c99] text-[0.9375rem] leading-relaxed">{r.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-navy relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <svg viewBox="0 0 800 400" className="w-full h-full">
            <circle cx="600" cy="200" r="300" stroke="white" strokeWidth="1" fill="none"/>
            <circle cx="600" cy="200" r="200" stroke="white" strokeWidth="1" fill="none"/>
            <circle cx="600" cy="200" r="100" stroke="white" strokeWidth="1" fill="none"/>
          </svg>
        </div>
        <div className="relative z-10 max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <h2 className="font-display text-4xl lg:text-5xl font-semibold text-white mb-5">
            Ready to simplify your finances?
          </h2>
          <p className="text-white/70 text-xl leading-relaxed mb-10">
            Let us handle the numbers so you can focus on growing your business.
          </p>
          <Link to="/contact" className="btn-white">Get in Touch</Link>
        </div>
      </section>
    </div>
  )
}
