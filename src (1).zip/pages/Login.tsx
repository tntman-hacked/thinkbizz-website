import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/auth'
import logo from '@/assets/thinkbizz-logo.png'

export default function Login() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', password: '', remember: false })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (user) {
    navigate(user.role === 'admin' ? '/admin' : '/dashboard', { replace: true })
    return null
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    await new Promise(r => setTimeout(r, 350))
    const result = login(form.email, form.password)
    setLoading(false)
    if (result.success) {
      const u = JSON.parse(localStorage.getItem('thinkbizz_auth') || '{}')
      navigate(u.role === 'admin' ? '/admin' : '/dashboard', { replace: true })
    } else {
      setError(result.error || 'An error occurred. Please try again.')
    }
  }

  return (
    <div className="min-h-screen bg-[#f7f9fc] flex items-center justify-center px-5 py-12">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-3 justify-center">
            <div className="h-14 w-14 overflow-hidden shrink-0">
              <img src={logo} alt="ThinkBizz Business Solutions" className="h-full w-full object-contain scale-250" />
            </div>
            <div className="text-left">
              <div className="font-display font-semibold text-navy text-lg">ThinkBizz Business Solutions</div>
            </div>
          </Link>
        </div>

        <div className="bg-white border border-[#d8e0ec] rounded-2xl p-8">
          <h1 className="font-display text-2xl font-semibold text-navy mb-1">Client Portal</h1>
          <p className="text-[#6b7c99] text-sm mb-8">Sign in to access your account and documents.</p>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 flex items-center gap-3 mb-5">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="shrink-0">
                <circle cx="8" cy="8" r="7" stroke="#ef4444" strokeWidth="1.25"/>
                <path d="M8 5v3.5M8 10.5v.5" stroke="#ef4444" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div>
              <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">Email Address</label>
              <input
                type="email"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="you@company.ca"
                required
                autoComplete="email"
                className="w-full border border-[#d8e0ec] rounded-lg px-4 py-3 text-[0.9375rem] text-[#1a2332] placeholder-[#9aabb8] bg-white outline-none transition-colors focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10"
              />
            </div>
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-sm font-semibold text-[#1a2332]">Password</label>
                <a href="mailto:info@thinkbizzsolutions.com" className="text-xs text-[#2461be] hover:underline font-medium">Forgot password?</a>
              </div>
              <input
                type="password"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                placeholder="••••••••"
                required
                autoComplete="current-password"
                className="w-full border border-[#d8e0ec] rounded-lg px-4 py-3 text-[0.9375rem] text-[#1a2332] placeholder-[#9aabb8] bg-white outline-none transition-colors focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10"
              />
            </div>

            <div className="flex items-center gap-2.5">
              <input
                type="checkbox"
                id="remember"
                checked={form.remember}
                onChange={e => setForm(f => ({ ...f, remember: e.target.checked }))}
                className="w-4 h-4 rounded border-[#d8e0ec] accent-navy cursor-pointer"
              />
              <label htmlFor="remember" className="text-sm text-[#3d5070] cursor-pointer">Remember me</label>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full justify-center mt-1">
              {loading ? (
                <>
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="6" stroke="white" strokeWidth="2" strokeDasharray="25 10"/>
                  </svg>
                  Signing in…
                </>
              ) : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-[#6b7c99] text-sm">
              Need access?{' '}
              <a href="mailto:info@thinkbizzsolutions.com" className="text-[#2461be] font-medium hover:underline">
                Contact ThinkBizz
              </a>
            </p>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link to="/" className="text-[#6b7c99] text-xs hover:text-navy transition-colors">
            ← Back to ThinkBizz website
          </Link>
        </div>
      </div>
    </div>
  )
}
