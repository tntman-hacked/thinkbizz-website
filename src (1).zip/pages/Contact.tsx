import { useState } from 'react'

/*
 * EMAIL DELIVERY SETUP — ACTION REQUIRED
 *
 * This form uses Formspree (https://formspree.io) to deliver submissions
 * to info@thinkbizzsolutions.com without exposing secrets in the frontend.
 *
 * To activate real email delivery:
 * 1. Sign up at https://formspree.io
 * 2. Create a new form and set the recipient to info@thinkbizzsolutions.com
 * 3. Copy the form ID (e.g. "xpzgkjwv") from the Formspree dashboard
 * 4. Add it to your environment: VITE_FORMSPREE_ID=your_form_id
 *
 * The Formspree form endpoint ID is a public routing identifier (not a secret).
 * It is safe to include in frontend code. Formspree routes the submission to
 * the recipient email you configure in your dashboard.
 *
 * Until VITE_FORMSPREE_ID is set, the form will show a setup notice.
 */

// Form ID is a public routing identifier, not a secret credential.
// It can also be overridden via VITE_FORMSPREE_ID in the environment.
const FORMSPREE_ID: string = (import.meta.env.VITE_FORMSPREE_ID as string | undefined) ?? 'xppwnkyb'

const serviceOptions = [
  'Bookkeeping & Virtual CFO',
  'Taxation',
  'Advisory',
  'Accounting Software',
  'Other',
]

type FormState = 'idle' | 'submitting' | 'success' | 'error'

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [formState, setFormState] = useState<FormState>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  const validate = () => {
    const e: Record<string, string> = {}
    if (!form.name.trim()) e.name = 'Full name is required.'
    if (!form.email.trim()) e.email = 'Email address is required.'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Please enter a valid email address.'
    if (!form.subject.trim()) e.subject = 'Subject is required.'
    if (!form.message.trim()) e.message = 'Please enter your message.'
    return e
  }

  const handleChange = (field: string, value: string) => {
    setForm(f => ({ ...f, [field]: value }))
    if (errors[field]) setErrors(e => { const n = { ...e }; delete n[field]; return n })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }
    setFormState('submitting')
    try {
      const res = await fetch(`https://formspree.io/f/${FORMSPREE_ID}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          subject: form.subject,
          message: form.message,
          _replyto: form.email,
          _subject: `ThinkBizz Enquiry: ${form.subject}`,
        }),
      })
      if (res.ok) {
        setFormState('success')
        setForm({ name: '', email: '', subject: '', message: '' })
      } else {
        const data = await res.json().catch(() => ({}))
        setFormState('error')
        setErrorMessage(data?.error || 'Submission failed. Please try again or email us directly.')
      }
    } catch {
      setFormState('error')
      setErrorMessage('A network error occurred. Please check your connection and try again, or email us directly at info@thinkbizzsolutions.com.')
    }
  }

  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-20 bg-navy">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="mb-4 text-xl sm:text-2xl font-semibold tracking-widest uppercase text-white">Contact</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight">Let's Talk.</h1>
            <p className="text-white/70 text-xl leading-relaxed">
              Whether you have a specific question or want to discuss how ThinkBizz can support your business, we are here to listen.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-20 bg-[#f7f9fc]">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Form */}
            <div className="lg:col-span-3">
              <div className="bg-white border border-[#d8e0ec] rounded-2xl p-8">
                <h2 className="font-display text-2xl font-semibold text-navy mb-2">Send us a message</h2>
                <p className="text-[#6b7c99] text-sm mb-7">
                  Your enquiry will be sent to{' '}
                  <a href="mailto:info@thinkbizzsolutions.com" className="text-[#2461be] font-medium">info@thinkbizzsolutions.com</a>.
                </p>

                {/* Success state */}
                {formState === 'success' && (
                  <div className="bg-[#e6f4ec] border border-[#2d7d4f]/30 rounded-xl p-5 mb-6 flex gap-3">
                    <div className="shrink-0 w-6 h-6 rounded-full bg-[#2d7d4f] flex items-center justify-center mt-0.5">
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                        <path d="M2 6l3 3 5-5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <div>
                      <p className="font-semibold text-[#2d7d4f]">Message sent successfully.</p>
                      <p className="text-[#3d5070] text-sm mt-0.5">
                        Your enquiry has been sent to info@thinkbizzsolutions.com. A member of our team will be in touch within one business day.
                      </p>
                    </div>
                  </div>
                )}

                {/* Error state */}
                {formState === 'error' && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6 flex gap-3">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="shrink-0 mt-0.5">
                      <circle cx="8" cy="8" r="7" stroke="#ef4444" strokeWidth="1.25"/>
                      <path d="M8 5v3.5M8 10.5v.5" stroke="#ef4444" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <p className="text-red-700 text-sm">{errorMessage}</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={e => handleChange('name', e.target.value)}
                        placeholder="Your full name"
                        autoComplete="name"
                        className={`w-full border rounded-lg px-4 py-3 text-[0.9375rem] text-[#1a2332] placeholder-[#9aabb8] outline-none transition-colors focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10 ${errors.name ? 'border-red-400 bg-red-50' : 'border-[#d8e0ec] bg-white'}`}
                      />
                      {errors.name && <p className="text-red-500 text-xs mt-1.5">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={e => handleChange('email', e.target.value)}
                        placeholder="you@company.ca"
                        autoComplete="email"
                        className={`w-full border rounded-lg px-4 py-3 text-[0.9375rem] text-[#1a2332] placeholder-[#9aabb8] outline-none transition-colors focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10 ${errors.email ? 'border-red-400 bg-red-50' : 'border-[#d8e0ec] bg-white'}`}
                      />
                      {errors.email && <p className="text-red-500 text-xs mt-1.5">{errors.email}</p>}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">
                      Subject <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={form.subject}
                      onChange={e => handleChange('subject', e.target.value)}
                      className={`w-full border rounded-lg px-4 py-3 text-[0.9375rem] outline-none transition-colors focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10 appearance-none bg-white cursor-pointer ${errors.subject ? 'border-red-400 bg-red-50 text-[#1a2332]' : 'border-[#d8e0ec]'} ${!form.subject ? 'text-[#9aabb8]' : 'text-[#1a2332]'}`}
                    >
                      <option value="">Select a subject…</option>
                      {serviceOptions.map(opt => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                      <option value="General Enquiry">General Enquiry</option>
                    </select>
                    {errors.subject && <p className="text-red-500 text-xs mt-1.5">{errors.subject}</p>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">
                      Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      value={form.message}
                      onChange={e => handleChange('message', e.target.value)}
                      placeholder="Tell us about your business and what you are looking for…"
                      rows={5}
                      className={`w-full border rounded-lg px-4 py-3 text-[0.9375rem] text-[#1a2332] placeholder-[#9aabb8] outline-none transition-colors focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10 resize-none ${errors.message ? 'border-red-400 bg-red-50' : 'border-[#d8e0ec] bg-white'}`}
                    />
                    {errors.message && <p className="text-red-500 text-xs mt-1.5">{errors.message}</p>}
                  </div>

                  <button
                    type="submit"
                    disabled={formState === 'submitting'}
                    className="btn-primary w-full justify-center mt-1"
                  >
                    {formState === 'submitting' ? (
                      <>
                        <svg className="animate-spin w-4 h-4" viewBox="0 0 16 16" fill="none">
                          <circle cx="8" cy="8" r="6" stroke="white" strokeWidth="2" strokeDasharray="25 10"/>
                        </svg>
                        Sending…
                      </>
                    ) : (
                      <>
                        Send Message
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                          <path d="M2 8h12M10 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </>
                    )}
                  </button>
                </form>
              </div>
            </div>

            {/* Contact Info */}
            <div className="lg:col-span-2 flex flex-col gap-5">
              <div className="bg-navy text-white rounded-2xl p-8">
                <h3 className="font-display text-xl font-semibold mb-6">Contact Information</h3>
                <div className="flex flex-col gap-5 text-sm">
                  <div>
                    <div className="text-white/50 text-xs font-semibold tracking-widest uppercase mb-1.5">Email</div>
                    <a
                      href="mailto:info@thinkbizzsolutions.com"
                      className="text-white/80 hover:text-white transition-colors"
                    >
                      info@thinkbizzsolutions.com
                    </a>
                  </div>
                  <div>
                    <div className="text-white/50 text-xs font-semibold tracking-widest uppercase mb-1.5">Website</div>
                    <span className="text-white/70">thinkbizzsolutions.com</span>
                  </div>
                  <div>
                    <div className="text-white/50 text-xs font-semibold tracking-widest uppercase mb-1.5">Response Time</div>
                    <span className="text-white/70">Within one business day</span>
                  </div>
                </div>
              </div>

              <div className="bg-white border border-[#d8e0ec] rounded-xl p-6">
                <h4 className="font-semibold text-navy mb-3">Book a consultation</h4>
                <p className="text-[#6b7c99] text-sm leading-relaxed mb-4">
                  Not sure where to start? Use the contact form and let us know a bit about your situation. We will get back to you to discuss your needs.
                </p>
                <div className="flex flex-col gap-2">
                  {['No commitment required', 'Personalized guidance', 'Available in-person or by video'].map(item => (
                    <div key={item} className="flex items-center gap-2 text-sm text-[#3d5070]">
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M2.5 7l3 3 6-5.5" stroke="#2d7d4f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
