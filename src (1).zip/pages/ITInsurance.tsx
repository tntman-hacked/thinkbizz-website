import { Link } from 'react-router-dom'

const softwareSolutions = [
  {
    name: 'QuickBooks Online',
    desc: 'Setup, configuration, and ongoing support for the leading cloud bookkeeping platform—ideal for businesses of all sizes.',
  },
  {
    name: 'Xero',
    desc: 'Implementation and configuration for small and growing businesses seeking a modern, collaborative accounting solution.',
  },
  {
    name: 'Wave Accounting',
    desc: 'Setup and training for startups and small businesses looking for a straightforward, accessible accounting platform.',
  },
]

const whatIsIncluded = [
  {
    title: 'Software selection guidance',
    desc: 'We match you with the right platform for your industry, team size, and workflow.',
  },
  {
    title: 'Implementation & data migration',
    desc: 'Clean migration from legacy systems with a properly structured chart of accounts.',
  },
  {
    title: 'Staff training',
    desc: 'One-on-one or group training sessions for your team so everyone is confident using the platform.',
  },
  {
    title: 'Ongoing support',
    desc: 'Responsive support as your business grows and your accounting needs evolve.',
  },
]

export default function AccountingSoftware() {
  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-20 bg-navy relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img
            src="https://images.unsplash.com/photo-1542081403278-ba5973c25c7a?w=1600&h=700&fit=crop&auto=format"
            alt="Professional office environment"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-navy/85" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="mb-4 text-xl sm:text-2xl font-semibold tracking-widest uppercase text-white">Accounting Software</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight">
              The Right Tools for Your Business.
            </h1>
            <p className="text-white/70 text-xl leading-relaxed mb-8">
              The right accounting software saves time, reduces errors, and gives you real-time visibility into your finances. We help you select, implement, and master the platform that fits your business.
            </p>
            <Link to="/contact" className="btn-white">Get in Touch</Link>
          </div>
        </div>
      </section>

      {/* Software Solutions */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <div className="section-label mb-3">Platforms We Support</div>
              <h2 className="font-display text-4xl font-semibold text-navy mb-5">
                Accounting Software Solutions
              </h2>
              <div className="divider-accent" />
              <p className="text-[#3d5070] text-lg leading-relaxed mt-6 mb-8">
                We support the leading cloud accounting platforms and can guide you through selection, onboarding, and long-term use so your financial tools work efficiently from day one.
              </p>
              <div className="flex flex-col gap-4">
                {softwareSolutions.map(s => (
                  <div key={s.name} className="border border-[#d8e0ec] rounded-xl p-5 flex gap-4 items-start hover:border-[#2461be]/40 transition-colors">
                    <div className="shrink-0 w-10 h-10 bg-[#eef2fb] rounded-lg flex items-center justify-center">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <rect x="1" y="1" width="14" height="10" rx="1.5" stroke="#2461be" strokeWidth="1.25"/>
                        <path d="M4 14h8M8 11v3" stroke="#2461be" strokeWidth="1.25" strokeLinecap="round"/>
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-navy text-[0.9375rem] mb-1">{s.name}</h4>
                      <p className="text-[#6b7c99] text-sm leading-relaxed">{s.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#f7f9fc] border border-[#d8e0ec] rounded-2xl p-8">
              <h3 className="font-display text-2xl font-semibold text-navy mb-3">What's included</h3>
              <p className="text-[#6b7c99] leading-relaxed mb-6">
                Our accounting software services go beyond simple setup. We provide end-to-end support to ensure your team is capable and confident.
              </p>
              <div className="flex flex-col gap-5">
                {whatIsIncluded.map(item => (
                  <div key={item.title} className="flex gap-4">
                    <div className="shrink-0 w-5 h-5 rounded-full bg-[#e6f4ec] flex items-center justify-center mt-0.5">
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                        <path d="M2 5l2.5 2.5L8 2.5" stroke="#2d7d4f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold text-navy text-sm">{item.title}</div>
                      <div className="text-[#6b7c99] text-sm mt-0.5">{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-navy">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <h2 className="font-display text-4xl font-semibold text-white mb-4">
            Let's find the right platform for your business.
          </h2>
          <p className="text-white/70 text-lg mb-8">
            Talk to us about your accounting software needs and we will recommend the best solution for your situation.
          </p>
          <Link to="/contact" className="btn-white">Get in Touch</Link>
        </div>
      </section>
    </div>
  )
}
