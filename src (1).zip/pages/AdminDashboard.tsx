import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/auth'

const statusColors: Record<string, { bg: string; text: string; dot: string }> = {
  active: { bg: 'bg-[#e6f4ec]', text: 'text-[#2d7d4f]', dot: 'bg-[#2d7d4f]' },
  pending: { bg: 'bg-[#fff8e6]', text: 'text-[#b8860b]', dot: 'bg-[#f5a623]' },
  completed: { bg: 'bg-[#eef2fb]', text: 'text-[#2461be]', dot: 'bg-[#2461be]' },
  cancelled: { bg: 'bg-red-50', text: 'text-red-600', dot: 'bg-red-400' },
}

type AdminTab = 'overview' | 'requests' | 'messages' | 'clients'

export default function AdminDashboard() {
  const { user, logout, serviceRequests, contactMessages } = useAuth()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<AdminTab>('overview')

  if (!user || user.role !== 'admin') { navigate('/login', { replace: true }); return null }

  const handleLogout = () => { logout(); navigate('/', { replace: true }) }

  const unreadMessages = contactMessages.filter(m => !m.read).length
  const pendingRequests = serviceRequests.filter(r => r.status === 'pending').length
  const activeRequests = serviceRequests.filter(r => r.status === 'active').length

  const uniqueClients = Array.from(new Set(serviceRequests.map(r => r.clientId))).map(id => {
    const req = serviceRequests.find(r => r.clientId === id)!
    return { id, name: req.clientName, email: req.clientEmail, requests: serviceRequests.filter(r => r.clientId === id).length }
  })

  const tabs: Array<{ id: AdminTab; label: string; badge?: number }> = [
    { id: 'overview', label: 'Overview' },
    { id: 'requests', label: 'Service Requests', badge: pendingRequests },
    { id: 'messages', label: 'Contact Messages', badge: unreadMessages },
    { id: 'clients', label: 'Clients' },
  ]

  return (
    <div className="min-h-screen bg-[#f7f9fc] flex flex-col">
      {/* Admin Header */}
      <header className="bg-navy border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-md bg-white/10 border border-white/20 flex items-center justify-center">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M3 14V9L9 4L15 9V14" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M7 14V11H11V14" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M6 7.5L9 5.5L12 7.5" stroke="#2d7d4f" strokeWidth="1.2" strokeLinecap="round"/>
                </svg>
              </div>
              <span className="font-display font-semibold text-white text-[1.0625rem]">ThinkBizz</span>
            </Link>
            <span className="bg-red-500/20 text-red-300 text-xs font-semibold px-2.5 py-1 rounded-full border border-red-400/30">Admin</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-right">
              <div className="text-white text-sm font-medium">{user.name}</div>
              <div className="text-white/50 text-xs">Administrator</div>
            </div>
            <button onClick={handleLogout} className="text-white/70 hover:text-white text-sm font-medium transition-colors">
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 max-w-7xl mx-auto w-full px-5 lg:px-8 py-8">
        {/* Admin notice */}
        <div className="bg-[#fff8e6] border border-[#f5a623]/40 rounded-xl px-5 py-3 mb-6 flex items-center gap-3">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M8 2L14 13H2L8 2z" stroke="#b8860b" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M8 7v3M8 11.5v.5" stroke="#b8860b" strokeWidth="1.25" strokeLinecap="round"/>
          </svg>
          <p className="text-[#b8860b] text-sm">
            <strong>Admin Panel — Demo Mode.</strong> In production, this panel connects to a secure database, role-based access control, and email notification services.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-[#d8e0ec] mb-6 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors border-b-2 -mb-px ${
                activeTab === tab.id
                  ? 'border-navy text-navy'
                  : 'border-transparent text-[#6b7c99] hover:text-navy'
              }`}
            >
              {tab.label}
              {tab.badge ? (
                <span className="bg-[#2461be] text-white text-xs font-bold px-1.5 py-0.5 rounded-full min-w-5 text-center">
                  {tab.badge}
                </span>
              ) : null}
            </button>
          ))}
        </div>

        {/* Overview */}
        {activeTab === 'overview' && (
          <div className="flex flex-col gap-6">
            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: 'Total Clients', value: uniqueClients.length, color: '#0f2044', icon: '👥' },
                { label: 'Active Services', value: activeRequests, color: '#2d7d4f', icon: '✅' },
                { label: 'Pending Requests', value: pendingRequests, color: '#f5a623', icon: '⏳' },
                { label: 'Unread Messages', value: unreadMessages, color: '#2461be', icon: '✉️' },
              ].map(stat => (
                <div key={stat.label} className="bg-white border border-[#d8e0ec] rounded-xl p-5">
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-2xl">{stat.icon}</span>
                    <div className="font-display text-3xl font-semibold" style={{ color: stat.color }}>{stat.value}</div>
                  </div>
                  <div className="text-[#6b7c99] text-xs font-medium uppercase tracking-widest">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Recent requests */}
            <div className="bg-white border border-[#d8e0ec] rounded-xl">
              <div className="px-6 py-4 border-b border-[#d8e0ec] flex justify-between items-center">
                <h3 className="font-semibold text-navy">Recent Service Requests</h3>
                <button onClick={() => setActiveTab('requests')} className="text-[#2461be] text-sm font-medium hover:underline">View all</button>
              </div>
              {serviceRequests.length === 0 ? (
                <div className="px-6 py-8 text-center text-[#9aabb8] text-sm">No service requests yet.</div>
              ) : (
                <div className="divide-y divide-[#f1f4f9]">
                  {serviceRequests.slice(0, 5).map(req => {
                    const s = statusColors[req.status]
                    return (
                      <div key={req.id} className="px-6 py-4 flex flex-wrap items-center justify-between gap-3">
                        <div className="min-w-0">
                          <div className="font-medium text-navy text-sm">{req.clientName}</div>
                          <div className="text-[#6b7c99] text-xs">{req.service}</div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${s.bg} ${s.text}`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                            {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                          </span>
                          <span className="text-[#9aabb8] text-xs">{req.date}</span>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* Recent messages */}
            <div className="bg-white border border-[#d8e0ec] rounded-xl">
              <div className="px-6 py-4 border-b border-[#d8e0ec] flex justify-between items-center">
                <h3 className="font-semibold text-navy">Recent Contact Messages</h3>
                <button onClick={() => setActiveTab('messages')} className="text-[#2461be] text-sm font-medium hover:underline">View all</button>
              </div>
              {contactMessages.slice(0, 3).map(msg => (
                <div key={msg.id} className={`px-6 py-4 border-b border-[#f1f4f9] last:border-0 ${!msg.read ? 'bg-[#f7f9fc]' : ''}`}>
                  <div className="flex justify-between items-start gap-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-navy text-sm">{msg.name}</span>
                        {!msg.read && <span className="w-2 h-2 rounded-full bg-[#2461be] shrink-0" />}
                      </div>
                      <div className="text-[#6b7c99] text-xs">{msg.email} · {msg.service}</div>
                      <div className="text-[#3d5070] text-sm mt-1 line-clamp-1">{msg.message}</div>
                    </div>
                    <span className="text-[#9aabb8] text-xs shrink-0">{msg.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Requests Tab */}
        {activeTab === 'requests' && (
          <div className="bg-white border border-[#d8e0ec] rounded-xl">
            <div className="px-6 py-4 border-b border-[#d8e0ec]">
              <h3 className="font-semibold text-navy">All Service Requests ({serviceRequests.length})</h3>
            </div>
            {serviceRequests.length === 0 ? (
              <div className="p-12 text-center text-[#9aabb8]">No service requests.</div>
            ) : (
              <div className="divide-y divide-[#f1f4f9]">
                {serviceRequests.map(req => {
                  const s = statusColors[req.status]
                  return (
                    <div key={req.id} className="p-5 flex flex-col sm:flex-row gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span className="font-semibold text-navy text-sm">{req.clientName}</span>
                          <span className="text-[#9aabb8] text-xs">·</span>
                          <span className="text-[#6b7c99] text-xs">{req.clientEmail}</span>
                        </div>
                        <div className="text-navy text-[0.9375rem] font-medium">{req.service}</div>
                        <p className="text-[#6b7c99] text-sm mt-1 leading-relaxed">{req.message}</p>
                        <div className="text-[#9aabb8] text-xs mt-2">{req.date} · ID: {req.id}</div>
                      </div>
                      <div className="shrink-0">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold ${s.bg} ${s.text}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                          {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                        </span>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="bg-white border border-[#d8e0ec] rounded-xl">
            <div className="px-6 py-4 border-b border-[#d8e0ec]">
              <h3 className="font-semibold text-navy">Contact Messages ({contactMessages.length})</h3>
            </div>
            {contactMessages.length === 0 ? (
              <div className="p-12 text-center text-[#9aabb8]">No messages.</div>
            ) : (
              <div className="divide-y divide-[#f1f4f9]">
                {contactMessages.map(msg => (
                  <div key={msg.id} className={`p-5 ${!msg.read ? 'bg-[#f7f9fc]' : ''}`}>
                    <div className="flex flex-wrap justify-between items-start gap-3 mb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-full bg-[#eef2fb] flex items-center justify-center shrink-0">
                          <span className="text-[#2461be] text-xs font-semibold">{msg.name.split(' ').map(n => n[0]).join('').slice(0,2)}</span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-navy text-sm">{msg.name}</span>
                            {!msg.read && <span className="bg-[#2461be] text-white text-[0.625rem] font-bold px-1.5 py-0.5 rounded-full">New</span>}
                          </div>
                          <div className="text-[#6b7c99] text-xs">{msg.email}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[#9aabb8] text-xs">{msg.date}</div>
                        <div className="text-[#2461be] text-xs font-medium mt-0.5">{msg.service}</div>
                      </div>
                    </div>
                    <p className="text-[#3d5070] text-sm leading-relaxed ml-11">{msg.message}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Clients Tab */}
        {activeTab === 'clients' && (
          <div className="bg-white border border-[#d8e0ec] rounded-xl">
            <div className="px-6 py-4 border-b border-[#d8e0ec]">
              <h3 className="font-semibold text-navy">Client Accounts ({uniqueClients.length})</h3>
            </div>
            {uniqueClients.length === 0 ? (
              <div className="p-12 text-center text-[#9aabb8]">No clients yet.</div>
            ) : (
              <div className="divide-y divide-[#f1f4f9]">
                {uniqueClients.map(client => (
                  <div key={client.id} className="px-6 py-4 flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-navy flex items-center justify-center">
                        <span className="text-white text-sm font-semibold">{client.name.split(' ').map(n => n[0]).join('').slice(0,2)}</span>
                      </div>
                      <div>
                        <div className="font-semibold text-navy text-sm">{client.name}</div>
                        <div className="text-[#6b7c99] text-xs">{client.email}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="font-semibold text-navy text-lg">{client.requests}</div>
                        <div className="text-[#9aabb8] text-xs">Requests</div>
                      </div>
                      <span className="bg-[#e6f4ec] text-[#2d7d4f] text-xs font-semibold px-2.5 py-1 rounded-full">Active</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
