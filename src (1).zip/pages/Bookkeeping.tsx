import { Link } from 'react-router-dom'

const services = [
  'Recording financial transactions',
  'Sales and purchase reconciliation',
  'GST reconciliation and CRA reporting',
  'Payroll reconciliation',
  'Accounts payable and receivable reconciliation',
  'Bank statement reconciliation',
  'Credit card reconciliation',
  'Journal entries and documentation',
  'General and subsidiary ledgers',
]

const cfoServices = [
  { title: 'Real-time Financial Reporting', desc: 'Stay informed with up-to-date financials, KPIs, and dashboards tailored to your business.' },
  { title: 'Cash Flow Management', desc: 'Proactive forecasting and monitoring to ensure your business is never caught short.' },
  { title: 'Strategic Financial Guidance', desc: 'Executive-level advice without the executive salary—on demand when you need it.' },
  { title: 'Budget & Variance Analysis', desc: 'Understand where you stand against plan and why, with clear, actionable insights.' },
]

export default function Bookkeeping() {
  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-20 bg-navy relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 hidden lg:block">
          <img
            src="https://images.unsplash.com/photo-1560221328-12fe60f83ab8?w=800&h=700&fit=crop&auto=format"
            alt="Financial data"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy/95 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="mb-4 text-xl sm:text-2xl font-semibold tracking-widest uppercase text-white">Bookkeeping & Virtual CFO</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight">
              Books that balance. Decisions that count.
            </h1>
            <p className="text-white/70 text-xl leading-relaxed mb-8">
              Keep your financials clean and your business intelligence sharp with comprehensive bookkeeping and real-time Virtual CFO services.
            </p>
            <Link to="/contact" className="btn-white">Get a Quote</Link>
          </div>
        </div>
      </section>

      {/* Bookkeeping Services */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <div className="section-label mb-3">Bookkeeping</div>
              <h2 className="font-display text-4xl font-semibold text-navy mb-5">
                Comprehensive Bookkeeping Services
              </h2>
              <div className="divider-accent" />
              <p className="text-[#3d5070] text-lg leading-relaxed mt-6 mb-8">
                Accurate, timely bookkeeping is the foundation of every strong business. We handle the detail work so you have the data to make confident decisions.
              </p>
              <ul className="flex flex-col gap-3">
                {services.map(s => (
                  <li key={s} className="flex items-start gap-3">
                    <div className="shrink-0 w-5 h-5 rounded-full bg-[#e6f4ec] flex items-center justify-center mt-0.5">
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                        <path d="M2 5l2.5 2.5L8 2.5" stroke="#2d7d4f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <span className="text-[#3d5070] text-[0.9375rem]">{s}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[#f7f9fc] border border-[#d8e0ec] rounded-2xl p-8">
              <div className="w-12 h-12 bg-[#eef2fb] rounded-xl flex items-center justify-center mb-6">
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                  <path d="M11 2C6.03 2 2 6.03 2 11s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9z" stroke="#2461be" strokeWidth="1.5"/>
                  <path d="M11 6v5l3 3" stroke="#2461be" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h3 className="font-display text-2xl font-semibold text-navy mb-3">Why clean books matter</h3>
              <p className="text-[#6b7c99] leading-relaxed mb-5">
                Disorganized books lead to missed deductions, CRA compliance issues, and decisions made on incomplete information. We eliminate the risk.
              </p>
              <div className="flex flex-col gap-4">
                {[
                  'CRA-ready records at any time',
                  'Accurate data for tax planning',
                  'Clear picture of business health',
                  'Informed borrowing and investment decisions',
                ].map(item => (
                  <div key={item} className="flex items-center gap-3 text-sm text-[#3d5070]">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M3 8l3.5 3.5 6.5-7" stroke="#2461be" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Virtual CFO */}
      <section className="py-24 bg-[#f7f9fc]">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-14">
            <div className="section-label mb-3">Virtual CFO</div>
            <h2 className="font-display text-4xl font-semibold text-navy mb-4">Real-time CFO, without the full-time cost</h2>
            <p className="text-[#6b7c99] text-lg max-w-2xl mx-auto">
              Access executive-level financial leadership as a service—strategic, responsive, and built around your business stage.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 gap-6">
            {cfoServices.map(s => (
              <div key={s.title} className="bg-white border border-[#d8e0ec] rounded-xl p-7 card">
                <div className="w-8 h-8 rounded-lg bg-[#eef2fb] flex items-center justify-center mb-4">
                  <div className="w-2 h-2 rounded-full bg-[#2461be]" />
                </div>
                <h3 className="font-semibold text-navy text-lg mb-2">{s.title}</h3>
                <p className="text-[#6b7c99] text-[0.9375rem] leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-navy">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <h2 className="font-display text-4xl font-semibold text-white mb-4">Ready to get started?</h2>
          <p className="text-white/70 text-lg mb-8">Tell us about your business and we will put together a tailored bookkeeping solution.</p>
          <Link to="/contact" className="btn-white">Get a Quote</Link>
        </div>
      </section>
    </div>
  )
}
