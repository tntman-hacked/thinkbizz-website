import { Link } from 'react-router-dom'

const advisoryServices = [
  { icon: '💰', title: 'Cash-Flow Projections', desc: 'Realistic forecasts that help you anticipate cash needs and plan financing in advance.' },
  { icon: '📑', title: 'Financial Statements', desc: 'Prepared and presented in accordance with Canadian accounting standards.' },
  { icon: '🏛️', title: 'ASPE / IFRS Compliant Reporting', desc: 'Fully compliant financial reporting for private enterprises and public companies.' },
  { icon: '🔍', title: 'Business Process Reviews', desc: 'Identify operational gaps, improve controls, and drive efficiency across your organization.' },
  { icon: '📦', title: 'Stock Counting & Reconciliation', desc: 'Accurate inventory counts, reconciliations, and variance analysis for product businesses.' },
  { icon: '🎓', title: 'ASPE Training', desc: 'Practical training for your finance team on Accounting Standards for Private Enterprises.' },
  { icon: '🌐', title: 'IFRS Training', desc: 'Expert guidance on International Financial Reporting Standards for your team.' },
  { icon: '📚', title: 'Taxation Training', desc: 'In-house training sessions to help your team understand tax obligations and planning strategies.' },
  { icon: '🏢', title: 'Company Formation & Incorporation', desc: 'Full incorporation support, from structure planning to CRA registration.' },
]

export default function Advisory() {
  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-20 bg-navy relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <svg viewBox="0 0 800 500" className="w-full h-full">
            <path d="M0 400 Q200 200 400 300 T800 200" stroke="white" strokeWidth="2" fill="none"/>
            <path d="M0 350 Q200 150 400 250 T800 150" stroke="white" strokeWidth="1" fill="none"/>
          </svg>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="mb-4 text-xl sm:text-2xl font-semibold tracking-widest uppercase text-white">Advisory</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight">
              Make Better Decisions. Build a Stronger Business.
            </h1>
            <p className="text-white/70 text-xl leading-relaxed mb-8">
              Strategic financial advisory rooted in experience, delivered with clarity. We are the trusted partner in your most important business decisions.
            </p>
            <Link to="/contact" className="btn-white">Talk to an Advisor</Link>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <div className="section-label mb-3">Our Approach</div>
            <h2 className="font-display text-4xl font-semibold text-navy mb-5">
              Advisory that goes beyond the spreadsheet
            </h2>
            <p className="text-[#3d5070] text-lg leading-relaxed">
              Numbers tell a story—but only if you know how to read them. Our advisory team translates financial data into strategic clarity, helping you understand not just where your business stands, but where it is heading and how to get it where you want it to be.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 pb-24 bg-[#f7f9fc]">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-12">
            <div className="section-label mb-3">Advisory Services</div>
            <h2 className="font-display text-4xl font-semibold text-navy mb-4">What we can do for you</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {advisoryServices.map(s => (
              <div key={s.title} className="bg-white border border-[#d8e0ec] rounded-xl p-6 card">
                <div className="text-2xl mb-3">{s.icon}</div>
                <h3 className="font-semibold text-navy text-[1.0625rem] mb-2">{s.title}</h3>
                <p className="text-[#6b7c99] text-sm leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-navy">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <h2 className="font-display text-4xl font-semibold text-white mb-4">Let's build your strategy together.</h2>
          <p className="text-white/70 text-lg mb-8">
            A conversation can clarify months of uncertainty. Reach out today to discuss your advisory needs.
          </p>
          <Link to="/contact" className="btn-white">Talk to an Advisor</Link>
        </div>
      </section>
    </div>
  )
}
