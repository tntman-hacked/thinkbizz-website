import { Link } from 'react-router-dom'

const complianceItems = [
  'Employment income',
  'Property income',
  'Investment and commission income',
  'Pension income',
  'Self-employed and sole proprietor income',
  'International income',
  'Current and past overdue returns',
  'Corporate T2 returns',
  'GST / PST returns',
]

const consultingItems = [
  { title: 'Tax Planning & Deductions', items: ['Home office', 'Medical expenses', 'Child care', 'Moving expenses', 'Training and tuition'] },
  { title: 'Tax Credits', items: ['Home Buyers Tax Credit', 'Disability Tax Credit', 'Child Benefits', 'GST Benefits'] },
  { title: 'Corporate Tax Strategy', items: ['Pre-incorporation planning', 'Salary vs. bonus vs. dividends', 'TFSA / FHSA / RRSP planning', 'Income splitting'] },
  { title: 'CRA & Refund Planning', items: ['Tax refund optimization', 'CRA notices and correspondence', 'Voluntary disclosure guidance'] },
]

export default function Taxation() {
  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-20 bg-navy relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 right-20 w-96 h-96 rounded-full border border-white/30" />
          <div className="absolute top-32 right-32 w-64 h-64 rounded-full border border-white/20" />
          <div className="absolute top-40 right-40 w-32 h-32 rounded-full border border-white/10" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="mb-4 text-xl sm:text-2xl font-semibold tracking-widest uppercase text-white">Taxation</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight">
              Tax Done Right. Every Time.
            </h1>
            <p className="text-white/70 text-xl leading-relaxed mb-8">
              From straightforward personal returns to complex corporate structures and strategic tax planning—we ensure full compliance and optimal outcomes.
            </p>
            <Link to="/contact" className="btn-white">Book a Tax Consultation</Link>
          </div>
        </div>
      </section>

      {/* Tax Compliance */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <div className="section-label mb-3">Tax Compliance</div>
              <h2 className="font-display text-4xl font-semibold text-navy mb-5">
                Complete, accurate returns. No exceptions.
              </h2>
              <div className="divider-accent" />
              <p className="text-[#3d5070] text-lg leading-relaxed mt-6 mb-8">
                We prepare and file all types of Canadian tax returns with precision—ensuring compliance, minimizing risk, and catching every deduction you are entitled to.
              </p>
              <ul className="grid grid-cols-1 gap-3">
                {complianceItems.map(item => (
                  <li key={item} className="flex items-center gap-3">
                    <div className="shrink-0 w-5 h-5 rounded-full bg-[#e6f4ec] flex items-center justify-center">
                      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                        <path d="M2 5l2.5 2.5L8 2.5" stroke="#2d7d4f" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </div>
                    <span className="text-[#3d5070] text-[0.9375rem]">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-navy rounded-2xl p-8 text-white">
              <h3 className="font-display text-2xl font-semibold mb-4">Why timely filing matters</h3>
              <p className="text-white/70 leading-relaxed mb-7">
                Late or inaccurate filing can result in penalties, interest charges, and unwanted CRA scrutiny. We take the complexity off your plate so your obligations are met—every year, on time.
              </p>
              <div className="flex flex-col gap-4">
                {[
                  { label: 'Individuals & families', icon: '👤' },
                  { label: 'Self-employed & contractors', icon: '💼' },
                  { label: 'Corporations (T2)', icon: '🏢' },
                  { label: 'Overdue & past returns', icon: '📋' },
                ].map(item => (
                  <div key={item.label} className="flex items-center gap-3 bg-white/10 rounded-lg px-4 py-3">
                    <span className="text-xl">{item.icon}</span>
                    <span className="text-white/90 font-medium text-[0.9375rem]">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tax Consulting */}
      <section className="py-24 bg-[#f7f9fc]">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="text-center mb-14">
            <div className="section-label mb-3">Tax Consulting</div>
            <h2 className="font-display text-4xl font-semibold text-navy mb-4">Strategic tax planning—year round</h2>
            <p className="text-[#6b7c99] text-lg max-w-2xl mx-auto">
              Filing season is just one part of tax management. We help you plan ahead to minimize your tax burden legally and intelligently.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {consultingItems.map(group => (
              <div key={group.title} className="bg-white border border-[#d8e0ec] rounded-xl p-7 card">
                <h3 className="font-display text-xl font-semibold text-navy mb-5">{group.title}</h3>
                <ul className="flex flex-col gap-2.5">
                  {group.items.map(item => (
                    <li key={item} className="flex items-center gap-3 text-[0.9375rem] text-[#3d5070]">
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M2.5 7l3 3 6-5.5" stroke="#2461be" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-navy">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <h2 className="font-display text-4xl font-semibold text-white mb-4">Start with a tax consultation.</h2>
          <p className="text-white/70 text-lg mb-8">
            Whether you need a simple return or a comprehensive tax strategy, we start with a conversation.
          </p>
          <Link to="/contact" className="btn-white">Book a Tax Consultation</Link>
        </div>
      </section>
    </div>
  )
}
