import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/auth'

const serviceOptions = ['Bookkeeping & Virtual CFO', 'Taxation', 'Advisory', 'Accounting Software', 'Other']

const statusColors: Record<string, { bg: string; text: string; dot: string }> = {
  active: { bg: 'bg-[#e6f4ec]', text: 'text-[#2d7d4f]', dot: 'bg-[#2d7d4f]' },
  pending: { bg: 'bg-[#fff8e6]', text: 'text-[#b8860b]', dot: 'bg-[#f5a623]' },
  completed: { bg: 'bg-[#eef2fb]', text: 'text-[#2461be]', dot: 'bg-[#2461be]' },
  cancelled: { bg: 'bg-red-50', text: 'text-red-600', dot: 'bg-red-400' },
}

type DashboardTab = 'overview' | 'services' | 'messages' | 'settings'

export default function ClientDashboard() {
  const { user, logout, serviceRequests, addServiceRequest } = useAuth()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview')
  const [showRequestForm, setShowRequestForm] = useState(false)
  const [requestConfirmed, setRequestConfirmed] = useState(false)
  const [reqForm, setReqForm] = useState({ service: '', message: '' })
  const [reqErrors, setReqErrors] = useState<Record<string, string>>({})

  if (!user) { navigate('/login', { replace: true }); return null }

  const myRequests = serviceRequests.filter(r => r.clientId === user.id)

  const handleLogout = () => { logout(); navigate('/', { replace: true }) }

  const handleRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const errs: Record<string, string> = {}
    if (!reqForm.service) errs.service = 'Please select a service.'
    if (!reqForm.message.trim()) errs.message = 'Please describe your needs.'
    if (Object.keys(errs).length > 0) { setReqErrors(errs); return }
    addServiceRequest({
      clientId: user.id,
      clientName: user.name,
      clientEmail: user.email,
      service: reqForm.service,
      status: 'pending',
      message: reqForm.message,
    })
    setShowRequestForm(false)
    setRequestConfirmed(true)
    setReqForm({ service: '', message: '' })
    setTimeout(() => setRequestConfirmed(false), 8000)
  }

  const tabs: Array<{ id: DashboardTab; label: string; icon: string }> = [
    { id: 'overview', label: 'Overview', icon: '⊞' },
    { id: 'services', label: 'Service Requests', icon: '📋' },
    { id: 'messages', label: 'Messages', icon: '✉️' },
    { id: 'settings', label: 'Account', icon: '⚙' },
  ]

  return (
    <div className="min-h-screen bg-[#f7f9fc] flex flex-col">
      {/* Dashboard Header */}
      <header className="bg-navy border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-md bg-white/10 border border-white/20 flex items-center justify-center">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M3 14V9L9 4L15 9V14" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M7 14V11H11V14" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M6 7.5L9 5.5L12 7.5" stroke="#2d7d4f" strokeWidth="1.2" strokeLinecap="round"/>
              </svg>
            </div>
            <span className="font-display font-semibold text-white text-[1.0625rem]">ThinkBizz</span>
          </Link>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center">
                <span className="text-white text-xs font-semibold">{user.name.split(' ').map(n => n[0]).join('').slice(0,2)}</span>
              </div>
              <div className="text-right">
                <div className="text-white text-sm font-medium">{user.name}</div>
                <div className="text-white/50 text-xs">{user.company || 'Client'}</div>
              </div>
            </div>
            <button onClick={handleLogout} className="text-white/70 hover:text-white text-sm font-medium transition-colors">
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 max-w-7xl mx-auto w-full px-5 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white border border-[#d8e0ec] rounded-xl p-4 mb-4">
              <div className="flex flex-col items-center text-center p-3 mb-3">
                <div className="w-14 h-14 rounded-full bg-navy flex items-center justify-center mb-3">
                  <span className="text-white font-semibold text-lg">{user.name.split(' ').map(n => n[0]).join('').slice(0,2)}</span>
                </div>
                <div className="font-semibold text-navy text-[0.9375rem]">{user.name}</div>
                {user.company && <div className="text-[#6b7c99] text-xs mt-0.5">{user.company}</div>}
                <div className="text-[#6b7c99] text-xs mt-0.5">{user.email}</div>
                <span className="mt-2 bg-[#e6f4ec] text-[#2d7d4f] text-xs font-semibold px-2.5 py-1 rounded-full">Active Client</span>
              </div>
            </div>
            <nav className="bg-white border border-[#d8e0ec] rounded-xl overflow-hidden">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 text-sm font-medium transition-colors text-left ${
                    activeTab === tab.id
                      ? 'bg-[#eef2fb] text-navy border-r-2 border-navy'
                      : 'text-[#3d5070] hover:bg-[#f7f9fc]'
                  }`}
                >
                  <span className="text-base">{tab.icon}</span>
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Main content */}
          <div className="lg:col-span-3">
            {/* Confirmation banner */}
            {requestConfirmed && (
              <div className="bg-[#e6f4ec] border border-[#2d7d4f]/30 rounded-xl p-4 mb-5 flex items-start gap-3">
                <div className="shrink-0 w-6 h-6 rounded-full bg-[#2d7d4f] flex items-center justify-center mt-0.5">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path d="M2 6l3 3 5-5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div>
                  <p className="font-semibold text-[#2d7d4f] text-sm">Your service request has been received.</p>
                  <p className="text-[#3d5070] text-sm mt-0.5">A confirmation has been sent to your email. Our team will be in touch within one business day.</p>
                  <p className="text-[#6b7c99] text-xs mt-1 italic">Note: In the live production system, real email notifications will be sent via the connected email service.</p>
                </div>
              </div>
            )}

            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="flex flex-col gap-5">
                <div className="bg-navy rounded-2xl p-6 text-white">
                  <p className="text-white/60 text-sm mb-1">Welcome back,</p>
                  <h2 className="font-display text-2xl font-semibold">{user.name}</h2>
                  {user.company && <p className="text-white/60 text-sm mt-1">{user.company}</p>}
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: 'Active Services', value: myRequests.filter(r => r.status === 'active').length, color: '#2d7d4f' },
                    { label: 'Total Requests', value: myRequests.length, color: '#2461be' },
                    { label: 'Completed', value: myRequests.filter(r => r.status === 'completed').length, color: '#0f2044' },
                  ].map(stat => (
                    <div key={stat.label} className="bg-white border border-[#d8e0ec] rounded-xl p-4 text-center">
                      <div className="font-display text-3xl font-semibold mb-1" style={{ color: stat.color }}>{stat.value}</div>
                      <div className="text-[#6b7c99] text-xs font-medium">{stat.label}</div>
                    </div>
                  ))}
                </div>

                {/* Recent Activity */}
                <div className="bg-white border border-[#d8e0ec] rounded-xl">
                  <div className="px-6 py-4 border-b border-[#d8e0ec] flex justify-between items-center">
                    <h3 className="font-semibold text-navy">Recent Service Requests</h3>
                    <button onClick={() => setActiveTab('services')} className="text-[#2461be] text-sm font-medium hover:underline">View all</button>
                  </div>
                  {myRequests.length === 0 ? (
                    <div className="px-6 py-10 text-center text-[#9aabb8] text-sm">No service requests yet.</div>
                  ) : (
                    <div className="divide-y divide-[#f1f4f9]">
                      {myRequests.slice(0, 3).map(req => {
                        const s = statusColors[req.status]
                        return (
                          <div key={req.id} className="px-6 py-4 flex items-start justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-navy text-sm">{req.service}</div>
                              <div className="text-[#6b7c99] text-xs mt-0.5 truncate">{req.message}</div>
                            </div>
                            <div className="shrink-0 flex flex-col items-end gap-1">
                              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${s.bg} ${s.text}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                                {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                              </span>
                              <span className="text-[#9aabb8] text-xs">{req.date}</span>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>

                {/* Documents Placeholder */}
                <div className="bg-white border border-[#d8e0ec] rounded-xl p-6">
                  <h3 className="font-semibold text-navy mb-3">Documents</h3>
                  <div className="bg-[#f7f9fc] border border-dashed border-[#c1cfe0] rounded-xl p-8 text-center">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" className="mx-auto mb-3">
                      <path d="M6 4h14l6 6v18a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2z" stroke="#9aabb8" strokeWidth="1.5" strokeLinecap="round"/>
                      <path d="M20 4v8h8M11 17h10M11 21h7" stroke="#9aabb8" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <p className="text-[#9aabb8] text-sm font-medium">Document management coming soon</p>
                    <p className="text-[#b8c8de] text-xs mt-1">Upload and manage your tax files, statements, and records securely.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Services Tab */}
            {activeTab === 'services' && (
              <div className="flex flex-col gap-5">
                <div className="flex justify-between items-center">
                  <h2 className="font-display text-xl font-semibold text-navy">Service Requests</h2>
                  <button
                    onClick={() => { setShowRequestForm(!showRequestForm); setRequestConfirmed(false) }}
                    className="btn-primary text-sm"
                    style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}
                  >
                    + New Request
                  </button>
                </div>

                {showRequestForm && (
                  <div className="bg-white border border-[#d8e0ec] rounded-xl p-6">
                    <h3 className="font-semibold text-navy mb-4">Request a Service</h3>
                    <form onSubmit={handleRequestSubmit} className="flex flex-col gap-4">
                      <div>
                        <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">Service</label>
                        <select
                          value={reqForm.service}
                          onChange={e => { setReqForm(f => ({ ...f, service: e.target.value })); if (reqErrors.service) setReqErrors(e => { const n = {...e}; delete n.service; return n }) }}
                          className={`w-full border rounded-lg px-4 py-3 text-sm outline-none focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10 ${reqErrors.service ? 'border-red-400' : 'border-[#d8e0ec]'}`}
                        >
                          <option value="">Select a service…</option>
                          {serviceOptions.map(s => <option key={s}>{s}</option>)}
                        </select>
                        {reqErrors.service && <p className="text-red-500 text-xs mt-1">{reqErrors.service}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-[#1a2332] mb-1.5">Describe your needs</label>
                        <textarea
                          rows={3}
                          value={reqForm.message}
                          onChange={e => { setReqForm(f => ({ ...f, message: e.target.value })); if (reqErrors.message) setReqErrors(e => { const n = {...e}; delete n.message; return n }) }}
                          placeholder="Please describe what you need help with…"
                          className={`w-full border rounded-lg px-4 py-3 text-sm outline-none focus:border-[#2461be] focus:ring-2 focus:ring-[#2461be]/10 resize-none ${reqErrors.message ? 'border-red-400' : 'border-[#d8e0ec]'}`}
                        />
                        {reqErrors.message && <p className="text-red-500 text-xs mt-1">{reqErrors.message}</p>}
                      </div>
                      <div className="flex gap-3">
                        <button type="submit" className="btn-primary text-sm" style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}>Submit Request</button>
                        <button type="button" onClick={() => setShowRequestForm(false)} className="btn-secondary text-sm" style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}>Cancel</button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="bg-white border border-[#d8e0ec] rounded-xl">
                  {myRequests.length === 0 ? (
                    <div className="p-12 text-center text-[#9aabb8]">
                      <p className="text-base font-medium mb-2">No service requests yet</p>
                      <p className="text-sm">Click "New Request" to request a service from ThinkBizz.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-[#f1f4f9]">
                      {myRequests.map(req => {
                        const s = statusColors[req.status]
                        return (
                          <div key={req.id} className="p-5 flex flex-col sm:flex-row sm:items-start gap-4">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start gap-3 flex-wrap">
                                <span className="font-semibold text-navy text-[0.9375rem]">{req.service}</span>
                                <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${s.bg} ${s.text}`}>
                                  <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                                  {req.status.charAt(0).toUpperCase() + req.status.slice(1)}
                                </span>
                              </div>
                              <p className="text-[#6b7c99] text-sm mt-1.5 leading-relaxed">{req.message}</p>
                              <p className="text-[#9aabb8] text-xs mt-2">Submitted: {req.date}</p>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Messages Tab */}
            {activeTab === 'messages' && (
              <div className="bg-white border border-[#d8e0ec] rounded-xl p-8 text-center">
                <div className="w-14 h-14 bg-[#eef2fb] rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2v10z" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h3 className="font-semibold text-navy mb-2">Secure Messaging</h3>
                <p className="text-[#6b7c99] text-sm max-w-sm mx-auto">Direct messaging with your ThinkBizz advisor will be available here once your account is fully activated. Use the <Link to="/contact" className="text-[#2461be] hover:underline">contact form</Link> in the meantime.</p>
              </div>
            )}

            {/* Settings Tab */}
            {activeTab === 'settings' && (
              <div className="flex flex-col gap-5">
                <h2 className="font-display text-xl font-semibold text-navy">Account Settings</h2>
                <div className="bg-white border border-[#d8e0ec] rounded-xl p-6">
                  <h3 className="font-semibold text-navy mb-5">Profile Information</h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {[
                      { label: 'Full Name', value: user.name },
                      { label: 'Email Address', value: user.email },
                      { label: 'Company', value: user.company || '—' },
                      { label: 'Client Since', value: user.joinDate || '—' },
                    ].map(field => (
                      <div key={field.label}>
                        <div className="text-xs font-semibold tracking-widest uppercase text-[#9aabb8] mb-1">{field.label}</div>
                        <div className="text-navy font-medium text-[0.9375rem]">{field.value}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-white border border-[#d8e0ec] rounded-xl p-6">
                  <h3 className="font-semibold text-navy mb-4">Security</h3>
                  <p className="text-[#6b7c99] text-sm mb-4">Password management, two-factor authentication, and security settings will be available in the production version.</p>
                  <button className="btn-secondary text-sm" style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}>Change Password</button>
                </div>
                <div className="bg-white border border-[#d8e0ec] rounded-xl p-6">
                  <h3 className="font-semibold text-navy mb-2">Sign Out</h3>
                  <p className="text-[#6b7c99] text-sm mb-4">You will be redirected to the ThinkBizz homepage.</p>
                  <button onClick={handleLogout} className="btn-secondary text-sm text-red-600 border-red-300 hover:bg-red-50 hover:text-red-700" style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}>Sign Out</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
