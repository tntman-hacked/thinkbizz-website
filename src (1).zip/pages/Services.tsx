import { Link } from 'react-router-dom'

const services = [
  {
    title: 'Bookkeeping & Virtual CFO',
    to: '/services/bookkeeping',
    tag: 'Financial Management',
    color: 'bg-[#eef2fb]',
    accentColor: '#2461be',
    desc: 'Keep your books clean, your cash flow clear, and your business decisions sharp. From daily transaction recording to strategic Virtual CFO support.',
    features: ['Transaction recording', 'Reconciliations', 'GST / CRA reporting', 'Virtual CFO services'],
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <path d="M10 6H8a2 2 0 00-2 2v14a2 2 0 002 2h12a2 2 0 002-2V8a2 2 0 00-2-2h-2" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round"/>
        <path d="M10 6a2 2 0 012-2h4a2 2 0 012 2v0a2 2 0 01-2 2h-4a2 2 0 01-2-2z" stroke="#2461be" strokeWidth="1.75"/>
        <path d="M10 14h8M10 18h6" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    title: 'Taxation',
    to: '/services/taxation',
    tag: 'Tax Services',
    color: 'bg-[#e6f4ec]',
    accentColor: '#2d7d4f',
    desc: 'Personal and corporate tax compliance, strategic consulting, and CRA correspondence. Tax done right, every time.',
    features: ['Personal & corporate returns', 'GST / PST returns', 'Tax planning', 'CRA notices'],
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <path d="M10 16l3 3 6-6" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
        <rect x="4" y="8" width="20" height="14" rx="2" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round"/>
        <path d="M8 8V6a2 2 0 012-2h8a2 2 0 012 2v2" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    title: 'Advisory',
    to: '/services/advisory',
    tag: 'Business Advisory',
    color: 'bg-[#eef2fb]',
    accentColor: '#2461be',
    desc: 'Trusted guidance for growth, planning, and financial decisions. IFRS-compliant reporting and company formation.',
    features: ['Projections', 'ASPE / IFRS reporting', 'Process reviews', 'Incorporation'],
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <path d="M4 20l6-6 4 4 8-9" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M18 11h4v4" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
  {
    title: 'Accounting Software',
    to: '/services/it-insurance',
    tag: 'Technology',
    color: 'bg-[#e6f4ec]',
    accentColor: '#2d7d4f',
    desc: 'Selection, implementation, and training for leading cloud accounting platforms—so your financial tools work as hard as you do.',
    features: ['QuickBooks Online', 'Xero', 'Wave Accounting', 'Staff training'],
    icon: (
      <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
        <rect x="3" y="5" width="22" height="15" rx="2" stroke="#2d7d4f" strokeWidth="1.75"/>
        <path d="M10 24h8M14 20v4" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round"/>
        <path d="M10 11l2.5 2.5 5-5" stroke="#2d7d4f" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
]

export default function Services() {
  return (
    <div>
      {/* Hero */}
      <section className="pt-36 pb-20 bg-navy">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="max-w-2xl">
            <div className="section-label mb-4 text-[#7bb3f0]">Our Services</div>
            <h1 className="font-display text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight break-words">
              Comprehensive Professional Services
            </h1>
            <p className="text-white/70 text-xl leading-relaxed">
              Every service we offer is built around your unique situation—not a standard package.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {services.map(s => (
              <div key={s.title} className="card p-8 group">
                <div className={`w-14 h-14 ${s.color} rounded-xl flex items-center justify-center mb-6`}>
                  {s.icon}
                </div>
                <div className="text-[0.75rem] font-semibold tracking-widest uppercase text-[#9aabb8] mb-2">{s.tag}</div>
                <h2 className="font-display text-3xl sm:text-4xl font-semibold text-white bg-navy rounded-lg p-4 mb-3 leading-snug">{s.title}</h2>
                <p className="text-[#6b7c99] leading-relaxed mb-6">{s.desc}</p>
                <ul className="grid grid-cols-2 gap-2 mb-7">
                  {s.features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-[#3d5070]">
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M2.5 7l3.5 3.5 5.5-7" stroke={s.accentColor} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>
                <Link to={s.to} className="btn-primary text-sm" style={{ padding: '0.625rem 1.375rem', fontSize: '0.875rem' }}>
                  Learn More
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Consultation CTA */}
      <section className="py-20 bg-[#f7f9fc] border-t border-[#d8e0ec]">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 text-center">
          <div className="w-14 h-14 bg-[#eef2fb] rounded-2xl flex items-center justify-center mx-auto mb-6">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2v10z" stroke="#2461be" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <h2 className="font-display text-3xl font-semibold text-navy mb-4">
            Not sure which service you need?
          </h2>
          <p className="text-[#6b7c99] text-lg mb-8">
            Contact us and we will help you identify exactly what your business requires.
          </p>
          <Link to="/contact" className="btn-primary">Get in Touch</Link>
        </div>
      </section>
    </div>
  )
}
