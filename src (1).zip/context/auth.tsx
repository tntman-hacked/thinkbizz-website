import { createContext, useContext, useState, type ReactNode } from 'react'

export interface User {
  id: string
  name: string
  email: string
  role: 'client' | 'admin'
  company?: string
  joinDate?: string
}

export interface ServiceRequest {
  id: string
  clientId: string
  clientName: string
  clientEmail: string
  service: string
  status: 'pending' | 'active' | 'completed' | 'cancelled'
  date: string
  message: string
}

export interface ContactMessage {
  id: string
  name: string
  email: string
  service: string
  message: string
  date: string
  read: boolean
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => { success: boolean; error?: string }
  logout: () => void
  serviceRequests: ServiceRequest[]
  addServiceRequest: (req: Omit<ServiceRequest, 'id' | 'date'>) => void
  contactMessages: ContactMessage[]
  addContactMessage: (msg: Omit<ContactMessage, 'id' | 'date' | 'read'>) => void
}

const DEMO_USERS: Array<User & { password: string }> = [
  {
    id: 'u-001',
    name: 'Sarah Mitchell',
    email: 'client@thinkbizz.ca',
    password: 'Client123!',
    role: 'client',
    company: 'Mitchell & Co. Consulting',
    joinDate: '2025-03-14',
  },
  {
    id: 'u-admin',
    name: 'Administrator',
    email: 'admin@thinkbizz.ca',
    password: 'Admin123!',
    role: 'admin',
    joinDate: '2024-01-01',
  },
]

const INITIAL_REQUESTS: ServiceRequest[] = [
  {
    id: 'sr-001',
    clientId: 'u-001',
    clientName: 'Sarah Mitchell',
    clientEmail: 'client@thinkbizz.ca',
    service: 'Bookkeeping & Virtual CFO',
    status: 'active',
    date: '2026-09-10',
    message: 'Monthly bookkeeping and quarterly Virtual CFO review for our consulting firm.',
  },
  {
    id: 'sr-002',
    clientId: 'u-001',
    clientName: 'Sarah Mitchell',
    clientEmail: 'client@thinkbizz.ca',
    service: 'Taxation',
    status: 'completed',
    date: '2026-04-22',
    message: 'Corporate T2 return for fiscal year 2025.',
  },
]

const INITIAL_MESSAGES: ContactMessage[] = [
  {
    id: 'msg-001',
    name: 'James Chen',
    email: 'james.chen@example.ca',
    service: 'Advisory',
    message: 'Looking for assistance with a business plan and cash-flow projections for our expansion into Ontario.',
    date: '2026-09-28',
    read: false,
  },
  {
    id: 'msg-002',
    name: 'Priya Sharma',
    email: 'priya@techventures.ca',
    service: 'Taxation',
    message: 'Need help filing overdue corporate T2 returns for the past two years.',
    date: '2026-09-27',
    read: false,
  },
  {
    id: 'msg-003',
    name: 'Robert Williams',
    email: 'rob.w@westcoastbistro.ca',
    service: 'Bookkeeping & Virtual CFO',
    message: 'Interested in monthly bookkeeping for my restaurant group (3 locations).',
    date: '2026-09-25',
    read: true,
  },
]

const STORAGE_KEY = 'thinkbizz_auth'
const REQUESTS_KEY = 'thinkbizz_requests'
const MESSAGES_KEY = 'thinkbizz_messages'

const AuthContext = createContext<AuthContextType | null>(null)

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      return saved ? JSON.parse(saved) : null
    } catch {
      return null
    }
  })

  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>(() => {
    try {
      const saved = localStorage.getItem(REQUESTS_KEY)
      return saved ? JSON.parse(saved) : INITIAL_REQUESTS
    } catch {
      return INITIAL_REQUESTS
    }
  })

  const [contactMessages, setContactMessages] = useState<ContactMessage[]>(() => {
    try {
      const saved = localStorage.getItem(MESSAGES_KEY)
      return saved ? JSON.parse(saved) : INITIAL_MESSAGES
    } catch {
      return INITIAL_MESSAGES
    }
  })

  const login = (email: string, password: string) => {
    const found = DEMO_USERS.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    )
    if (!found) return { success: false, error: 'Invalid email address or password.' }
    const { password: _, ...userWithoutPassword } = found
    setUser(userWithoutPassword)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(userWithoutPassword))
    return { success: true }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem(STORAGE_KEY)
  }

  const addServiceRequest = (req: Omit<ServiceRequest, 'id' | 'date'>) => {
    const newReq: ServiceRequest = {
      ...req,
      id: `sr-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
    }
    const updated = [newReq, ...serviceRequests]
    setServiceRequests(updated)
    localStorage.setItem(REQUESTS_KEY, JSON.stringify(updated))
  }

  const addContactMessage = (msg: Omit<ContactMessage, 'id' | 'date' | 'read'>) => {
    const newMsg: ContactMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      read: false,
    }
    const updated = [newMsg, ...contactMessages]
    setContactMessages(updated)
    localStorage.setItem(MESSAGES_KEY, JSON.stringify(updated))
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, serviceRequests, addServiceRequest, contactMessages, addContactMessage }}>
      {children}
    </AuthContext.Provider>
  )
}
