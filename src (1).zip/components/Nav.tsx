import { useState, useEffect } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/auth'
import logo from '@/assets/thinkbizz-logo.png'

const navLinks = [
  { label: 'Home', to: '/' },
  { label: 'About', to: '/about' },
  {
    label: 'Services',
    to: '/services',
    children: [
      { label: 'Bookkeeping & Virtual CFO', to: '/services/bookkeeping' },
      { label: 'Taxation', to: '/services/taxation' },
      { label: 'Advisory', to: '/services/advisory' },
      { label: 'Accounting Software', to: '/services/it-insurance' },
    ],
  },
  { label: 'FAQ', to: '/faq' },
  { label: 'Contact', to: '/contact' },
]

export default function Nav() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [servicesOpen, setServicesOpen] = useState(false)
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (mobileOpen) document.body.style.overflow = 'hidden'
    else document.body.style.overflow = ''
    return () => { document.body.style.overflow = '' }
  }, [mobileOpen])

  const handleLogout = () => {
    logout()
    navigate('/')
    setMobileOpen(false)
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 bg-white transition-shadow duration-200 ${scrolled ? 'nav-scrolled' : 'border-b border-[#d8e0ec]'}`}
    >
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        <div className="flex items-center justify-between" style={{ height: '4.5rem' }}>
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 shrink-0" onClick={() => setMobileOpen(false)}>
            <div className="h-14 w-14 overflow-hidden shrink-0">
              <img
                src={logo}
                alt="ThinkBizz Business Solutions logo"
                className="h-full w-full object-contain scale-250"
              />
            </div>
            <div className="hidden sm:block">
              <span className="font-display font-semibold text-navy text-xl sm:text-2xl leading-tight block max-w-72">ThinkBizz Business Solutions</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden xl:flex items-center gap-1">
            {navLinks.map(link =>
              link.children ? (
                <div key={link.label} className="relative" onMouseEnter={() => setServicesOpen(true)} onMouseLeave={() => setServicesOpen(false)}>
                  <button className="flex items-center gap-1.5 px-4 py-2 text-[0.9375rem] font-medium text-[#1a2332] hover:text-navy rounded-md hover:bg-[#f7f9fc] transition-colors">
                    {link.label}
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className={`transition-transform ${servicesOpen ? 'rotate-180' : ''}`}>
                      <path d="M2 4L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  </button>
                  {servicesOpen && (
                    <div className="absolute top-full left-0 pt-1 w-64">
                      <div className="bg-white border border-[#d8e0ec] rounded-lg shadow-lg overflow-hidden">
                        {link.children.map(child => (
                          <NavLink
                            key={child.to}
                            to={child.to}
                            className={({ isActive }) =>
                              `block px-5 py-3 text-sm font-medium transition-colors ${isActive ? 'bg-[#eef2fb] text-navy' : 'text-[#3d5070] hover:bg-[#f7f9fc] hover:text-navy'}`
                            }
                          >
                            {child.label}
                          </NavLink>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === '/'}
                  className={({ isActive }) =>
                    `px-4 py-2 text-[0.9375rem] font-medium rounded-md transition-colors ${isActive ? 'text-navy bg-[#eef2fb]' : 'text-[#1a2332] hover:text-navy hover:bg-[#f7f9fc]'}`
                  }
                >
                  {link.label}
                </NavLink>
              )
            )}
          </nav>

          {/* Desktop Right */}
          <div className="hidden xl:flex items-center gap-3">
            {user ? (
              <>
                <Link
                  to={user.role === 'admin' ? '/admin' : '/dashboard'}
                  className="text-[0.9375rem] font-medium text-[#1a2332] hover:text-navy transition-colors"
                >
                  {user.role === 'admin' ? 'Admin Panel' : 'My Dashboard'}
                </Link>
                <button onClick={handleLogout} className="btn-secondary" style={{ padding: '0.5rem 1.25rem', fontSize: '0.875rem' }}>
                  Sign Out
                </button>
              </>
            ) : (
              <Link to="/contact" className="btn-primary" style={{ padding: '0.625rem 1.375rem', fontSize: '0.9rem' }}>
                Book a Consultation
              </Link>
            )}
          </div>

          {/* Mobile Hamburger */}
          <button
            className="xl:hidden flex items-center justify-center w-10 h-10 rounded-md text-ink hover:bg-surface transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? (
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M4 4L16 16M16 4L4 16" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round"/>
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M3 5H17M3 10H17M3 15H17" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round"/>
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="xl:hidden fixed inset-0 top-[4.5rem] bg-white z-40 overflow-y-auto">
          <div className="px-5 py-6 flex flex-col gap-1">
            {navLinks.map(link =>
              link.children ? (
                <div key={link.label}>
                  <button
                    className="w-full flex items-center justify-between px-4 py-3.5 text-base font-medium text-[#1a2332] rounded-md hover:bg-[#f7f9fc] transition-colors"
                    onClick={() => setMobileServicesOpen(!mobileServicesOpen)}
                  >
                    {link.label}
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" className={`transition-transform ${mobileServicesOpen ? 'rotate-180' : ''}`}>
                      <path d="M2 4.5L7 9.5L12 4.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  </button>
                  {mobileServicesOpen && (
                    <div className="ml-4 border-l-2 border-[#eef2fb] pl-4 mb-1">
                      {link.children.map(child => (
                        <NavLink
                          key={child.to}
                          to={child.to}
                          onClick={() => setMobileOpen(false)}
                          className={({ isActive }) =>
                            `block px-3 py-3 text-[0.9375rem] font-medium rounded-md transition-colors ${isActive ? 'text-navy' : 'text-[#3d5070]'}`
                          }
                        >
                          {child.label}
                        </NavLink>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === '/'}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `block px-4 py-3.5 text-base font-medium rounded-md transition-colors ${isActive ? 'text-navy bg-[#eef2fb]' : 'text-[#1a2332] hover:bg-[#f7f9fc]'}`
                  }
                >
                  {link.label}
                </NavLink>
              )
            )}

            <div className="mt-4 pt-4 border-t border-[#d8e0ec] flex flex-col gap-3">
              {user ? (
                <>
                  <Link
                    to={user.role === 'admin' ? '/admin' : '/dashboard'}
                    onClick={() => setMobileOpen(false)}
                    className="btn-secondary text-center justify-center"
                  >
                    {user.role === 'admin' ? 'Admin Panel' : 'My Dashboard'}
                  </Link>
                  <button onClick={handleLogout} className="btn-secondary text-center justify-center">Sign Out</button>
                </>
              ) : (
                <Link to="/contact" onClick={() => setMobileOpen(false)} className="btn-primary text-center justify-center">
                  Book a Consultation
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
