import { useState } from 'react'

const faqs = [
  {
    q: 'What services does ThinkBizz Business Solutions offer?',
    a: 'ThinkBizz provides a comprehensive range of professional services including bookkeeping, Virtual CFO services, personal and corporate taxation, business advisory, and accounting software solutions. Each engagement is tailored to the specific needs of the client.',
  },
  {
    q: 'Who does ThinkBizz work with?',
    a: 'We work with a broad range of clients including self-employed individuals, sole proprietors, small and medium-sized businesses, corporations, and professionals across various industries throughout Canada.',
  },
  {
    q: 'How do I get started with ThinkBizz?',
    a: 'Simply reach out through our contact form or email us at info@thinkbizzsolutions.com. A member of our team will respond promptly to discuss your needs and how we can help.',
  },
  {
    q: 'What is a Virtual CFO and does my business need one?',
    a: 'A Virtual CFO provides the strategic financial oversight of a Chief Financial Officer on a flexible, outsourced basis — without the cost of a full-time hire. This service is ideal for growing businesses that need real-time financial reporting, cash-flow management, and strategic guidance but are not yet at the stage to bring a CFO in-house.',
  },
  {
    q: 'Can you help with overdue or past-due tax returns?',
    a: 'Yes. We assist clients with filing current and past overdue tax returns, including corporate T2 returns and personal T1 returns. Addressing outstanding filings as early as possible can help reduce penalties and interest charges.',
  },
  {
    q: 'What documents should I gather for my tax return?',
    a: 'The documents required depend on your situation. Common items include T4 slips, T3 slips, RRSP/TFSA/FHSA statements, business income and expense records, rental income records, receipts for deductible expenses (medical, charitable donations, child care), and any notices of assessment from previous years. We can provide a tailored document checklist once we understand your circumstances.',
  },
  {
    q: 'Do you offer tax planning services, or only tax filing?',
    a: 'We offer both. In addition to preparing and filing returns, we provide tax planning and consulting throughout the year — including strategies around income splitting, salary versus dividends, TFSA and RRSP planning, pre-incorporation planning, and minimizing overall tax liability.',
  },
  {
    q: 'What accounting software do you support?',
    a: 'We support leading cloud and desktop accounting platforms including QuickBooks Online, Xero, and Wave. We can assist with software selection, implementation, data migration, and training for your team.',
  },
  {
    q: 'How do I send documents to ThinkBizz securely?',
    a: 'Our team will provide you with a secure method for submitting sensitive financial documents once your engagement begins. Please contact us at info@thinkbizzsolutions.com for guidance on document submission prior to onboarding.',
  },
  {
    q: 'How can I contact ThinkBizz Business Solutions?',
    a: 'You can reach us by email at info@thinkbizzsolutions.com or by submitting the contact form on our Contact page. We aim to respond to all enquiries within one business day.',
  },
]

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const toggle = (i: number) => setOpenIndex(prev => (prev === i ? null : i))

  return (
    <section className="py-24 bg-[#f7f9fc]">
      <div className="max-w-4xl mx-auto px-5 lg:px-8">
        <div className="text-center mb-14">
          <div className="section-label mb-3">FAQ</div>
          <h2 className="font-display text-4xl font-semibold text-navy mb-4">Frequently Asked Questions</h2>
          <p className="text-[#6b7c99] text-lg max-w-xl mx-auto">
            Common questions about our services and how we work with clients.
          </p>
        </div>

        <div className="flex flex-col gap-2">
          {faqs.map((faq, i) => {
            const isOpen = openIndex === i
            return (
              <div
                key={i}
                className={`bg-white border rounded-xl overflow-hidden transition-all duration-200 ${isOpen ? 'border-[#2461be]/30 shadow-sm' : 'border-[#d8e0ec]'}`}
              >
                <button
                  onClick={() => toggle(i)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
                  aria-expanded={isOpen}
                >
                  <span className={`font-semibold text-[0.9375rem] leading-snug transition-colors ${isOpen ? 'text-navy' : 'text-[#1a2332]'}`}>
                    {faq.q}
                  </span>
                  <span className={`shrink-0 w-7 h-7 rounded-full flex items-center justify-center transition-colors ${isOpen ? 'bg-navy' : 'bg-[#eef2fb]'}`}>
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 12 12"
                      fill="none"
                      className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                    >
                      <path d="M2 4L6 8L10 4" stroke={isOpen ? 'white' : '#2461be'} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </span>
                </button>

                <div
                  style={{
                    maxHeight: isOpen ? '400px' : '0',
                    opacity: isOpen ? 1 : 0,
                    overflow: 'hidden',
                    transition: 'max-height 0.25s ease, opacity 0.2s ease',
                  }}
                >
                  <div className="px-6 pb-5">
                    <div className="border-t border-[#f1f4f9] pt-4">
                      <p className="text-[#3d5070] text-[0.9375rem] leading-relaxed">{faq.a}</p>
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        <div className="mt-10 text-center">
          <p className="text-[#6b7c99] text-sm">
            Have a question not listed here?{' '}
            <a href="mailto:info@thinkbizzsolutions.com" className="text-[#2461be] font-semibold hover:underline">
              Email us at info@thinkbizzsolutions.com
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
