import { Link, useLocation } from 'react-router-dom'
import logo from '@/assets/thinkbizz-logo.png'

const services = [
  { label: 'Bookkeeping & Virtual CFO', to: '/services/bookkeeping' },
  { label: 'Taxation', to: '/services/taxation' },
  { label: 'Advisory', to: '/services/advisory' },
  { label: 'Accounting Software', to: '/services/it-insurance' },
]

const navigation = [
  { label: 'Home', to: '/' },
  { label: 'About Us', to: '/about' },
  { label: 'Services', to: '/services' },
  { label: 'FAQ', to: '/faq' },
  { label: 'Contact', to: '/contact' },
]

export default function Footer() {
  const { pathname } = useLocation()
  return (
    <footer className="bg-navy text-white">
      <div className="max-w-7xl mx-auto px-5 lg:px-8">
        {/* Top section */}
        <div className="py-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-5">
              <div className="h-14 w-14 overflow-hidden bg-white rounded-lg shrink-0">
                <img
                  src={logo}
                  alt="ThinkBizz Business Solutions"
                  className="h-full w-full object-contain scale-250"
                />
              </div>
              <span className="font-display font-semibold text-white text-lg leading-tight">
                ThinkBizz Business Solutions
              </span>
            </div>
            <p className="text-white/60 text-sm leading-relaxed max-w-xs mb-6">
              {pathname === '/contact'
                ? 'Canadian Accounting Outsourcing, Tax & Advisory. Smart financial solutions for ambitious business.'
                : 'Canadian Accounting Outsourcing, Tax & Advisory. Smart financial solutions for ambitious businesses.'}
            </p>
            <div className="flex flex-col gap-2 text-sm text-white/60">
              <a
                href="mailto:info@thinkbizzsolutions.com"
                className="hover:text-white transition-colors flex items-center gap-2"
              >
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <rect x="1" y="3" width="12" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.25"/>
                  <path d="M1 5l6 4 6-4" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round"/>
                </svg>
                info@thinkbizzsolutions.com
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-white/40 text-xs font-semibold tracking-widest uppercase mb-5">Navigation</h4>
            <ul className="flex flex-col gap-3">
              {navigation.map(item => (
                <li key={item.to}>
                  <Link to={item.to} className="text-white/70 hover:text-white text-sm transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-white/40 text-xs font-semibold tracking-widest uppercase mb-5">Services</h4>
            <ul className="flex flex-col gap-3">
              {services.map(item => (
                <li key={item.to}>
                  <Link to={item.to} className="text-white/70 hover:text-white text-sm transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/40 text-xs">
            © {new Date().getFullYear()} ThinkBizz Business Solutions. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-white/40 hover:text-white/70 text-xs transition-colors">Privacy Policy</a>
            <a href="#" className="text-white/40 hover:text-white/70 text-xs transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
